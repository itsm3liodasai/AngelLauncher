package com.angelclient.launcher

import android.app.Application

class AngelClientApp : Application()
