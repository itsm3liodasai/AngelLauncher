package com.angelclient.launcher.data

import android.content.Context
import com.angelclient.launcher.model.JavaVersion
import com.angelclient.launcher.model.MinecraftInstance
import com.angelclient.launcher.model.ModLoader
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

class InstanceManager(private val context: Context) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val instancesRoot = File(context.filesDir, "instances").apply { mkdirs() }
    private val indexFile = File(instancesRoot, "instances.json")

    fun listInstances(): List<MinecraftInstance> {
        if (!indexFile.exists()) {
            val defaultInstance = MinecraftInstance(
                id = "default-1-21-1",
                name = "Angel 1.21.1 (Fabric)",
                mcVersion = "1.21.1",
                loader = ModLoader.FABRIC,
                loaderVersion = "0.16.5",
                javaVersion = JavaVersion.JAVA_21
            )
            saveAll(listOf(defaultInstance))
            ensureInstanceDirs(defaultInstance.id)
            return listOf(defaultInstance)
        }
        return runCatching {
            json.decodeFromString<List<MinecraftInstance>>(indexFile.readText())
        }.getOrDefault(emptyList())
    }

    fun createInstance(
        name: String,
        mcVersion: String,
        loader: ModLoader,
        loaderVersion: String = ""
    ): MinecraftInstance {
        val javaVer = when {
            mcVersion.startsWith("1.8") || mcVersion.startsWith("1.12") -> JavaVersion.JAVA_8
            mcVersion.startsWith("1.16") || mcVersion.startsWith("1.18") || mcVersion.startsWith("1.19") -> JavaVersion.JAVA_17
            else -> JavaVersion.JAVA_21
        }
        val instance = MinecraftInstance(
            id = UUID.randomUUID().toString().take(8),
            name = name.ifBlank { "Minecraft $mcVersion" },
            mcVersion = mcVersion,
            loader = loader,
            loaderVersion = loaderVersion,
            javaVersion = javaVer
        )
        val current = listInstances().toMutableList()
        current.add(instance)
        saveAll(current)
        ensureInstanceDirs(instance.id)
        return instance
    }

    fun duplicateInstance(id: String): MinecraftInstance? {
        val source = listInstances().find { it.id == id } ?: return null
        val copy = source.copy(
            id = UUID.randomUUID().toString().take(8),
            name = "${source.name} (Copy)",
            createdAt = System.currentTimeMillis()
        )
        val current = listInstances().toMutableList()
        current.add(copy)
        saveAll(current)
        ensureInstanceDirs(copy.id)
        return copy
    }

    fun deleteInstance(id: String) {
        val current = listInstances().filterNot { it.id == id }
        saveAll(current)
        File(instancesRoot, id).deleteRecursively()
    }

    fun getInstanceDir(id: String): File = ensureInstanceDirs(id)

    fun getModsDir(id: String): File = File(getInstanceDir(id), "mods").apply { mkdirs() }

    private fun ensureInstanceDirs(id: String): File {
        val dir = File(instancesRoot, id).apply { mkdirs() }
        listOf("mods", "resourcepacks", "saves", "screenshots", "config", "logs").forEach {
            File(dir, it).mkdirs()
        }
        return dir
    }

    private fun saveAll(list: List<MinecraftInstance>) {
        indexFile.writeText(json.encodeToString(list))
    }
}
