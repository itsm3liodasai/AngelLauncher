package com.angelclient.launcher.ui.navigation

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FolderCopy
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.angelclient.launcher.data.AccountManager
import com.angelclient.launcher.data.InstanceManager
import com.angelclient.launcher.runtime.RuntimeManager
import com.angelclient.launcher.ui.screens.HomeScreen
import com.angelclient.launcher.ui.screens.InstancesScreen
import com.angelclient.launcher.ui.screens.LockerScreen
import com.angelclient.launcher.ui.screens.ModsScreen
import com.angelclient.launcher.ui.screens.ModulesScreen
import com.angelclient.launcher.ui.screens.SettingsScreen
import com.angelclient.launcher.ui.screens.SocialScreen
import com.angelclient.launcher.ui.screens.StoreScreen

enum class NavTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    INSTANCES("Instances", Icons.Default.FolderCopy),
    MODS("Mods", Icons.Default.Extension),
    MODULES("Modules", Icons.Default.Tune),
    LOCKER("Locker", Icons.Default.Checkroom),
    SOCIAL("Social", Icons.Default.Group),
    STORE("Store", Icons.Default.ShoppingBag),
    SETTINGS("Settings", Icons.Default.Settings)
}

@Composable
fun AngelClientRoot() {
    val context = LocalContext.current
    val instanceManager = remember { InstanceManager(context) }
    val accountManager = remember { AccountManager(context) }
    val runtimeManager = remember { RuntimeManager() }

    var selectedTab by remember { mutableStateOf(NavTab.HOME) }
    var instances by remember { mutableStateOf(instanceManager.listInstances()) }
    var selectedInstanceId by remember { mutableStateOf(instances.firstOrNull()?.id ?: "") }
    var accounts by remember { mutableStateOf(accountManager.listAccounts()) }
    var launchLogs by remember { mutableStateOf<List<String>>(emptyList()) }

    val activeInstance = instances.find { it.id == selectedInstanceId } ?: instances.firstOrNull()
    val activeAccount = accounts.find { it.isActive } ?: accounts.firstOrNull()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            bottomBar = {
                if (!useRail) {
                    NavigationBar {
                        NavTab.entries.take(5).forEach { tab ->
                            NavigationBarItem(
                                selected = selectedTab == tab,
                                onClick = { selectedTab = tab },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail {
                        NavTab.entries.forEach { tab ->
                            NavigationRailItem(
                                selected = selectedTab == tab,
                                onClick = { selectedTab = tab },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) }
                            )
                        }
                    }
                }

                when (selectedTab) {
                    NavTab.HOME -> HomeScreen(
                        activeInstance = activeInstance,
                        activeAccount = activeAccount,
                        launchLogs = launchLogs,
                        onLaunch = {
                            if (activeInstance != null) {
                                val res = runtimeManager.launchInstance(
                                    activeInstance,
                                    activeAccount,
                                    instanceManager.getInstanceDir(activeInstance.id)
                                )
                                launchLogs = res.logs
                            }
                        },
                        onAddOfflineAccount = { username ->
                            accountManager.addOfflineAccount(username)
                            accounts = accountManager.listAccounts()
                        }
                    )
                    NavTab.INSTANCES -> InstancesScreen(
                        instances = instances,
                        selectedInstanceId = selectedInstanceId,
                        onSelect = { selectedInstanceId = it },
                        onCreate = { name, ver, loader ->
                            val created = instanceManager.createInstance(name, ver, loader)
                            instances = instanceManager.listInstances()
                            selectedInstanceId = created.id
                        },
                        onDuplicate = { id ->
                            instanceManager.duplicateInstance(id)
                            instances = instanceManager.listInstances()
                        },
                        onDelete = { id ->
                            instanceManager.deleteInstance(id)
                            instances = instanceManager.listInstances()
                            if (selectedInstanceId == id) {
                                selectedInstanceId = instances.firstOrNull()?.id ?: ""
                            }
                        }
                    )
                    NavTab.MODS -> ModsScreen(
                        activeInstance = activeInstance,
                        instanceManager = instanceManager
                    )
                    NavTab.MODULES -> ModulesScreen()
                    NavTab.LOCKER -> LockerScreen()
                    NavTab.SOCIAL -> SocialScreen(activeAccount = activeAccount)
                    NavTab.STORE -> StoreScreen()
                    NavTab.SETTINGS -> SettingsScreen(
                        accounts = accounts,
                        launchLogs = launchLogs,
                        onSetActiveAccount = { id ->
                            accountManager.setActiveAccount(id)
                            accounts = accountManager.listAccounts()
                        },
                        onRemoveAccount = { id ->
                            accountManager.removeAccount(id)
                            accounts = accountManager.listAccounts()
                        }
                    )
                }
            }
        }
    }
}
