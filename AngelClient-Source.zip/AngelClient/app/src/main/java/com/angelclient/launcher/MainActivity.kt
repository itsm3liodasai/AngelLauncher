package com.angelclient.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.angelclient.launcher.ui.navigation.AngelClientRoot
import com.angelclient.launcher.ui.theme.AngelClientTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AngelClientTheme {
                AngelClientRoot()
            }
        }
    }
}
