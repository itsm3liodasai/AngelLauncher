package com.angelclient.launcher.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
enum class ModLoader(val displayName: String) {
    VANILLA("Vanilla"),
    FABRIC("Fabric"),
    FORGE("Forge"),
    QUILT("Quilt"),
    NEOFORGE("NeoForge")
}

@Serializable
enum class JavaVersion(val label: String, val major: Int) {
    JAVA_8("Java 8", 8),
    JAVA_17("Java 17", 17),
    JAVA_21("Java 21", 21)
}

@Serializable
data class MinecraftInstance(
    val id: String,
    val name: String,
    val mcVersion: String,
    val loader: ModLoader = ModLoader.VANILLA,
    val loaderVersion: String = "",
    val javaVersion: JavaVersion = JavaVersion.JAVA_21,
    val allocatedRamMb: Int = 2048,
    val resolutionWidth: Int = 1280,
    val resolutionHeight: Int = 720,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
enum class AccountType {
    MICROSOFT,
    OFFLINE
}

@Serializable
data class UserAccount(
    val id: String,
    val username: String,
    val type: AccountType,
    val uuid: String = "",
    val isActive: Boolean = false
)

@Serializable
data class ModrinthSearchResponse(
    val hits: List<ModrinthProject> = emptyList(),
    @SerialName("total_hits") val totalHits: Int = 0
)

@Serializable
data class ModrinthProject(
    @SerialName("project_id") val projectId: String,
    val slug: String = "",
    val title: String,
    val description: String = "",
    val author: String = "",
    val downloads: Int = 0,
    @SerialName("icon_url") val iconUrl: String? = null,
    val categories: List<String> = emptyList(),
    @SerialName("project_type") val projectType: String = "mod"
)

@Serializable
data class ModrinthVersion(
    val id: String,
    @SerialName("project_id") val projectId: String,
    val name: String,
    @SerialName("version_number") val versionNumber: String,
    @SerialName("game_versions") val gameVersions: List<String> = emptyList(),
    val loaders: List<String> = emptyList(),
    val files: List<ModrinthFile> = emptyList()
)

@Serializable
data class ModrinthFile(
    val url: String,
    val filename: String,
    val primary: Boolean = false,
    val size: Long = 0L
)

@Serializable
data class ClientModule(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val enabled: Boolean = false,
    val keybind: String = "None",
    val implementedInGameMod: Boolean = false
)

@Serializable
data class HudElement(
    val id: String,
    val name: String,
    val xPercent: Float,
    val yPercent: Float,
    val scale: Float = 1.0f,
    val opacity: Float = 0.85f,
    val enabled: Boolean = true,
    val sampleText: String
)

@Serializable
data class AppSettings(
    val defaultRamMb: Int = 2048,
    val defaultJava: JavaVersion = JavaVersion.JAVA_21,
    val chromebookPreset: Boolean = true,
    val accentColorHex: Long = 0xFF38BDF8,
    val showFps: Boolean = true
)
