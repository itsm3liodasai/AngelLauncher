package com.angelclient.launcher.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.angelclient.launcher.data.InstanceManager
import com.angelclient.launcher.model.MinecraftInstance
import com.angelclient.launcher.model.ModrinthProject
import com.angelclient.launcher.network.CurseForgeApi
import com.angelclient.launcher.network.CurseForgeMod
import com.angelclient.launcher.network.ModrinthApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ModsScreen(
    activeInstance: MinecraftInstance?,
    instanceManager: InstanceManager
) {
    val scope = rememberCoroutineScope()
    var tabIndex by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var modrinthResults by remember { mutableStateOf<List<ModrinthProject>>(emptyList()) }
    var curseForgeResults by remember { mutableStateOf<List<CurseForgeMod>>(emptyList()) }
    var statusMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Mods", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Text(
            "Target Instance: ${activeInstance?.name ?: "None"} (${activeInstance?.mcVersion ?: "-"})",
            style = MaterialTheme.typography.bodyMedium
        )

        TabRow(selectedTabIndex = tabIndex) {
            Tab(selected = tabIndex == 0, onClick = { tabIndex = 0 }, text = { Text("Modrinth") })
            Tab(selected = tabIndex == 1, onClick = { tabIndex = 1 }, text = { Text("CurseForge") })
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search mods...") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                scope.launch {
                    statusMessage = "Searching..."
                    if (tabIndex == 0) {
                        runCatching {
                            ModrinthApi.service.searchProjects(query = query.ifBlank { "sodium" })
                        }.onSuccess {
                            modrinthResults = it.hits
                            statusMessage = "Found ${it.hits.size} Modrinth results."
                        }.onFailure {
                            statusMessage = "Modrinth error: ${it.message}"
                        }
                    } else {
                        if (!CurseForgeApi.isConfigured()) {
                            statusMessage = "CurseForge API key not configured in local.properties."
                        } else {
                            runCatching {
                                CurseForgeApi.service.searchMods(searchFilter = query.ifBlank { "jei" })
                            }.onSuccess {
                                curseForgeResults = it.data
                                statusMessage = "Found ${it.data.size} CurseForge results."
                            }.onFailure {
                                statusMessage = "CurseForge error: ${it.message}"
                            }
                        }
                    }
                }
            }) {
                Text("Search")
            }
        }

        if (statusMessage.isNotBlank()) {
            Text(statusMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }

        if (tabIndex == 0) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(modrinthResults, key = { it.projectId }) { mod ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.padding(14.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(mod.title, style = MaterialTheme.typography.titleMedium)
                                Text(mod.description, maxLines = 2, style = MaterialTheme.typography.bodySmall)
                                Text("By ${mod.author} • ${mod.downloads} downloads", style = MaterialTheme.typography.labelSmall)
                            }
                            Button(
                                enabled = activeInstance != null,
                                onClick = {
                                    val inst = activeInstance ?: return@Button
                                    scope.launch {
                                        statusMessage = "Downloading ${mod.title}..."
                                        runCatching {
                                            val versions = ModrinthApi.service.getProjectVersions(
                                                projectId = mod.projectId,
                                                gameVersions = "[\"${inst.mcVersion}\"]"
                                            )
                                            val file = versions.firstOrNull()?.files?.firstOrNull()
                                                ?: error("No compatible version for ${inst.mcVersion}")
                                            val body = ModrinthApi.service.downloadFile(file.url)
                                            withContext(Dispatchers.IO) {
                                                val dest = File(instanceManager.getModsDir(inst.id), file.filename)
                                                dest.writeBytes(body.bytes())
                                            }
                                            file.filename
                                        }.onSuccess { filename ->
                                            statusMessage = "Installed $filename to ${inst.name}"
                                        }.onFailure {
                                            statusMessage = "Install failed: ${it.message}"
                                        }
                                    }
                                }
                            ) {
                                Text("Install")
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(curseForgeResults, key = { it.id }) { mod ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(mod.name, style = MaterialTheme.typography.titleMedium)
                            Text(mod.summary, maxLines = 2, style = MaterialTheme.typography.bodySmall)
                            Text("${mod.downloadCount} downloads", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}
