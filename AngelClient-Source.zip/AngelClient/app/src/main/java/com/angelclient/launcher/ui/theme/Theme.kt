package com.angelclient.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AngelBg = Color(0xFF0B1120)
val AngelSurface = Color(0xFF111827)
val AngelSurfaceVariant = Color(0xFF1E293B)
val AngelBlue = Color(0xFF38BDF8)
val AngelBlueDark = Color(0xFF0284C7)
val AngelText = Color(0xFFF8FAFC)
val AngelTextMuted = Color(0xFF94A3B8)

private val AngelDarkColorScheme = darkColorScheme(
    primary = AngelBlue,
    onPrimary = Color(0xFF082F49),
    secondary = AngelBlueDark,
    background = AngelBg,
    onBackground = AngelText,
    surface = AngelSurface,
    onSurface = AngelText,
    surfaceVariant = AngelSurfaceVariant,
    onSurfaceVariant = AngelTextMuted
)

@Composable
fun AngelClientTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AngelDarkColorScheme,
        content = content
    )
}
