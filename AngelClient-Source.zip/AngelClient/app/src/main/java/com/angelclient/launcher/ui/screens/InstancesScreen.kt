package com.angelclient.launcher.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.angelclient.launcher.model.MinecraftInstance
import com.angelclient.launcher.model.ModLoader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstancesScreen(
    instances: List<MinecraftInstance>,
    selectedInstanceId: String,
    onSelect: (String) -> Unit,
    onCreate: (String, String, ModLoader) -> Unit,
    onDuplicate: (String) -> Unit,
    onDelete: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var version by remember { mutableStateOf("1.21.1") }
    var selectedLoader by remember { mutableStateOf(ModLoader.FABRIC) }
    var loaderMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Instances", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Create Isolated Instance", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Instance Name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = version,
                        onValueChange = { version = it },
                        label = { Text("MC Version") },
                        singleLine = true,
                        modifier = Modifier.weight(0.6f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExposedDropdownMenuBox(
                        expanded = loaderMenuExpanded,
                        onExpandedChange = { loaderMenuExpanded = !loaderMenuExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = selectedLoader.displayName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Loader") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = loaderMenuExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = loaderMenuExpanded,
                            onDismissRequest = { loaderMenuExpanded = false }
                        ) {
                            ModLoader.entries.forEach { loader ->
                                DropdownMenuItem(
                                    text = { Text(loader.displayName) },
                                    onClick = {
                                        selectedLoader = loader
                                        loaderMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    Button(
                        onClick = {
                            onCreate(name, version.ifBlank { "1.21.1" }, selectedLoader)
                            name = ""
                        }
                    ) {
                        Text("Create")
                    }
                }
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(instances, key = { it.id }) { instance ->
                val isSelected = instance.id == selectedInstanceId
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant
                        else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(instance.name, style = MaterialTheme.typography.titleMedium)
                            Text("${instance.mcVersion} • ${instance.loader.displayName} • ${instance.javaVersion.label}")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onSelect(instance.id) }) {
                                Text(if (isSelected) "Selected" else "Select")
                            }
                            OutlinedButton(onClick = { onDuplicate(instance.id) }) {
                                Text("Duplicate")
                            }
                            OutlinedButton(onClick = { onDelete(instance.id) }) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
    }
}
