package com.angelclient.launcher.data

import android.content.Context
import com.angelclient.launcher.model.AccountType
import com.angelclient.launcher.model.UserAccount
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

class AccountManager(context: Context) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val accountsFile = File(context.filesDir, "accounts.json")

    fun listAccounts(): List<UserAccount> {
        if (!accountsFile.exists()) return emptyList()
        return runCatching {
            json.decodeFromString<List<UserAccount>>(accountsFile.readText())
        }.getOrDefault(emptyList())
    }

    fun addOfflineAccount(username: String): UserAccount {
        val cleanName = username.trim().take(16).ifBlank { "Player" }
        val account = UserAccount(
            id = UUID.randomUUID().toString().take(8),
            username = cleanName,
            type = AccountType.OFFLINE,
            uuid = UUID.nameUUIDFromBytes("OfflinePlayer:$cleanName".toByteArray()).toString(),
            isActive = true
        )
        val updated = listAccounts().map { it.copy(isActive = false) } + account
        accountsFile.writeText(json.encodeToString(updated))
        return account
    }

    fun setActiveAccount(id: String) {
        val updated = listAccounts().map { it.copy(isActive = it.id == id) }
        accountsFile.writeText(json.encodeToString(updated))
    }

    fun removeAccount(id: String) {
        val updated = listAccounts().filterNot { it.id == id }
        accountsFile.writeText(json.encodeToString(updated))
    }
}
