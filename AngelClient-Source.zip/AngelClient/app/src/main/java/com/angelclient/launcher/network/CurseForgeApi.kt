package com.angelclient.launcher.network

import com.angelclient.launcher.BuildConfig
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.Query

@Serializable
data class CurseForgeSearchResponse(
    val data: List<CurseForgeMod> = emptyList()
)

@Serializable
data class CurseForgeMod(
    val id: Int,
    val name: String,
    val summary: String = "",
    val downloadCount: Long = 0
)

interface CurseForgeService {
    @GET("v1/mods/search")
    suspend fun searchMods(
        @Query("gameId") gameId: Int = 432, // Minecraft
        @Query("searchFilter") searchFilter: String,
        @Query("pageSize") pageSize: Int = 20
    ): CurseForgeSearchResponse
}

object CurseForgeApi {
    private val json = Json { ignoreUnknownKeys = true }

    fun isConfigured(): Boolean = BuildConfig.CURSEFORGE_API_KEY.isNotBlank()

    private val client = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val request = chain.request().newBuilder()
                .header("x-api-key", BuildConfig.CURSEFORGE_API_KEY)
                .header("Accept", "application/json")
                .build()
            chain.proceed(request)
        }
        .build()

    val service: CurseForgeService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.curseforge.com/")
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(CurseForgeService::class.java)
    }
}
