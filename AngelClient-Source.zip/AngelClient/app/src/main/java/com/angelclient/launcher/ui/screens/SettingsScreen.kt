package com.angelclient.launcher.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.angelclient.launcher.model.UserAccount
import com.angelclient.launcher.network.CurseForgeApi

@Composable
fun SettingsScreen(
    accounts: List<UserAccount>,
    launchLogs: List<String>,
    onSetActiveAccount: (String) -> Unit,
    onRemoveAccount: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("API Configuration", style = MaterialTheme.typography.titleMedium)
                Text("Modrinth API: Enabled (Public v2)")
                Text(
                    if (CurseForgeApi.isConfigured()) "CurseForge API: Configured via local.properties"
                    else "CurseForge API: Not configured (set CURSEFORGE_API_KEY in local.properties)"
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Accounts (${accounts.size})", style = MaterialTheme.typography.titleMedium)
                accounts.forEach { acc ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${acc.username} (${acc.type})${if (acc.isActive) " [Active]" else ""}")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (!acc.isActive) {
                                OutlinedButton(onClick = { onSetActiveAccount(acc.id) }) {
                                    Text("Use")
                                }
                            }
                            OutlinedButton(onClick = { onRemoveAccount(acc.id) }) {
                                Text("Remove")
                            }
                        }
                    }
                }
            }
        }

        if (launchLogs.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth().weight(1f)) {
                LazyColumn(modifier = Modifier.padding(12.dp)) {
                    items(launchLogs) { line ->
                        Text(line, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
