package com.angelclient.launcher.runtime

import com.angelclient.launcher.model.MinecraftInstance
import com.angelclient.launcher.model.UserAccount
import java.io.File

data class LaunchResult(
    val launched: Boolean,
    val logs: List<String>
)

/**
 * Coordinates Java runtime selection (Java 8 / 17 / 21), JVM arguments,
 * and delegation to an Android-compatible Minecraft Java runtime (e.g. Amethyst / PojavLauncher).
 */
class RuntimeManager {
    fun launchInstance(
        instance: MinecraftInstance,
        account: UserAccount?,
        instanceDir: File
    ): LaunchResult {
        val logs = mutableListOf<String>()
        logs.add("[AngelRuntime] Preparing instance '${instance.name}' (${instance.mcVersion})")
        logs.add("[AngelRuntime] Loader: ${instance.loader.displayName} ${instance.loaderVersion}")
        logs.add("[AngelRuntime] Java Runtime: ${instance.javaVersion.label} | RAM: ${instance.allocatedRamMb} MB")
        logs.add("[AngelRuntime] Game Directory: ${instanceDir.absolutePath}")
        logs.add("[AngelRuntime] Account: ${account?.username ?: "None selected"} (${account?.type ?: "N/A"})")

        if (account == null) {
            logs.add("[ERROR] No active account selected. Add an Offline or Microsoft account first.")
            return LaunchResult(launched = false, logs = logs)
        }

        // Integration point for Amethyst / PojavLauncher native runtime (JRE + LWJGL + GL4ES/Angle)
        logs.add("[INFO] Native JRE/LWJGL runtime binaries are not bundled in this source template.")
        logs.add("[INFO] See README.md -> 'Runtime Setup' to link Amethyst/PojavLauncher native libraries.")

        return LaunchResult(launched = false, logs = logs)
    }
}
