package com.angelclient.launcher.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.angelclient.launcher.model.ClientModule

@Composable
fun ModulesScreen() {
    var search by remember { mutableStateOf("") }
    var modules by remember {
        mutableStateOf(
            listOf(
                ClientModule("fps", "FPS Display", "HUD", "Shows real-time frames per second.", true, "None", false),
                ClientModule("coords", "Coordinates", "HUD", "Displays X / Y / Z and facing direction.", true, "None", false),
                ClientModule("keystrokes", "Keystrokes", "HUD", "Displays WASD, mouse clicks, and spacebar.", false, "None", false),
                ClientModule("zoom", "Zoom", "Visual", "Smooth camera zoom (requires companion in-game mod).", true, "C", false),
                ClientModule("freelook", "Free Look", "Visual", "360-degree camera look without packet manipulation.", false, "Left Alt", false),
                ClientModule("crosshair", "Custom Crosshair", "Visual", "Customizable crosshair shape and color.", false, "None", false),
                ClientModule("armors", "Armor Status", "HUD", "Shows equipped armor durability.", true, "None", false),
                ClientModule("potions", "Potion Effects", "HUD", "Shows active status effects and timers.", false, "None", false)
            )
        )
    }

    val filtered = modules.filter {
        it.name.contains(search, ignoreCase = true) || it.category.contains(search, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Client Modules & HUD", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Text(
            "Note: In-game rendering requires the Angel Client companion Fabric/Forge mod inside the launched instance.",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            label = { Text("Search modules...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { mod ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(14.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${mod.name} (${mod.category})", style = MaterialTheme.typography.titleMedium)
                            Text(mod.description, style = MaterialTheme.typography.bodySmall)
                            Text("Keybind: ${mod.keybind} • In-Game Mod: Pending", style = MaterialTheme.typography.labelSmall)
                        }
                        Switch(
                            checked = mod.enabled,
                            onCheckedChange = { checked ->
                                modules = modules.map { if (it.id == mod.id) it.copy(enabled = checked) else it }
                            }
                        )
                    }
                }
            }
        }
    }
}
