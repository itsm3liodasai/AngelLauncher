package com.angelclient.launcher.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun LockerScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Locker", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Text("Visual-only cosmetics (Capes, Skies, Auras, Wings, Themes).", style = MaterialTheme.typography.bodyMedium)
        listOf("Angel Blue Cape", "Starlight Custom Sky", "Halo Aura", "Celestial Wings").forEach { item ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(item, style = MaterialTheme.typography.titleMedium)
                    Text("Original Angel Client cosmetic asset • Visual-only", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
