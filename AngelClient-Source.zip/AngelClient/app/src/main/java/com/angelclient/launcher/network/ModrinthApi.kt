package com.angelclient.launcher.network

import com.angelclient.launcher.model.ModrinthSearchResponse
import com.angelclient.launcher.model.ModrinthVersion
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Streaming
import retrofit2.http.Url

interface ModrinthService {
    @GET("v2/search")
    suspend fun searchProjects(
        @Query("query") query: String,
        @Query("facets") facets: String? = null,
        @Query("index") index: String = "downloads",
        @Query("limit") limit: Int = 20
    ): ModrinthSearchResponse

    @GET("v2/project/{id}/version")
    suspend fun getProjectVersions(
        @Path("id") projectId: String,
        @Query("loaders") loaders: String? = null,
        @Query("game_versions") gameVersions: String? = null
    ): List<ModrinthVersion>

    @Streaming
    @GET
    suspend fun downloadFile(@Url fileUrl: String): ResponseBody
}

object ModrinthApi {
    private val json = Json { ignoreUnknownKeys = true }

    private val client = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val request = chain.request().newBuilder()
                .header("User-Agent", "AngelClient/1.0.0 (Android)")
                .build()
            chain.proceed(request)
        }
        .build()

    val service: ModrinthService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.modrinth.com/")
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(ModrinthService::class.java)
    }
}
