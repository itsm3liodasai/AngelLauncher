package com.angelclient.launcher.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.angelclient.launcher.model.MinecraftInstance
import com.angelclient.launcher.model.UserAccount

@Composable
fun HomeScreen(
    activeInstance: MinecraftInstance?,
    activeAccount: UserAccount?,
    launchLogs: List<String>,
    onLaunch: () -> Unit,
    onAddOfflineAccount: (String) -> Unit
) {
    var offlineUsername by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Angel Client", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Text("Minecraft Java Edition Launcher for Android & ChromeOS", style = MaterialTheme.typography.bodyMedium)

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Selected Instance", style = MaterialTheme.typography.titleMedium)
                if (activeInstance != null) {
                    Text("${activeInstance.name} • ${activeInstance.mcVersion} (${activeInstance.loader.displayName})")
                    Text("Runtime: ${activeInstance.javaVersion.label} • ${activeInstance.allocatedRamMb} MB RAM")
                } else {
                    Text("No instance selected.")
                }
                Spacer(modifier = Modifier.height(4.dp))
                Button(onClick = onLaunch, enabled = activeInstance != null) {
                    Text("Launch Minecraft")
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Account", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (activeAccount != null) "Active: ${activeAccount.username} (${activeAccount.type})"
                    else "No account active"
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = offlineUsername,
                        onValueChange = { offlineUsername = it },
                        label = { Text("Offline Username") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(onClick = {
                        if (offlineUsername.isNotBlank()) {
                            onAddOfflineAccount(offlineUsername)
                            offlineUsername = ""
                        }
                    }) {
                        Text("Add Offline")
                    }
                }
            }
        }

        if (launchLogs.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth().weight(1f)) {
                LazyColumn(modifier = Modifier.padding(12.dp)) {
                    items(launchLogs) { line ->
                        Text(line, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
