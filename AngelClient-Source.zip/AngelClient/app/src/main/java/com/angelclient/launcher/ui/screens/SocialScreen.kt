package com.angelclient.launcher.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.angelclient.launcher.model.UserAccount

@Composable
fun SocialScreen(activeAccount: UserAccount?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Social", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Profile", style = MaterialTheme.typography.titleMedium)
                Text("Active User: ${activeAccount?.username ?: "Not signed in"}")
            }
        }
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Online Social Services", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Friends list, online status, group chat, and voice chat require a live Angel Client backend server. No fake/simulated users are displayed.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
