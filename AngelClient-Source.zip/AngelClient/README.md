# Angel Client — Android & ChromeOS Minecraft Java Launcher

Angel Client is a Kotlin + Jetpack Compose Android Studio project for a Minecraft Java Edition launcher inspired by BunnyLauncher's feature set, designed for Android phones, tablets, and ChromeOS (ARM64 & x86-64).

## Project Structure
- `app/src/main/java/com/angelclient/launcher/data/` — `InstanceManager` (isolated instance folders) & `AccountManager` (Offline + Microsoft OAuth2 structure).
- `app/src/main/java/com/angelclient/launcher/network/` — Real `ModrinthApi` (v2) & `CurseForgeApi` (v1, key-injected via `BuildConfig`).
- `app/src/main/java/com/angelclient/launcher/runtime/` — `RuntimeManager` for Java 8/17/21 selection and Amethyst/PojavLauncher native runtime integration.
- `app/src/main/java/com/angelclient/launcher/ui/` — 8-tab responsive UI (Home, Instances, Mods, Modules, Locker, Social, Store, Settings) with `NavigationRail` for Chromebooks/tablets and `NavigationBar` for phones.

## Build Instructions
1. Open the `AngelClient` folder in **Android Studio** (Ladybug or newer recommended).
2. Copy `local.properties.example` to `local.properties` and set your Android SDK path (`sdk.dir=...`).
3. *(Optional)* Add your CurseForge API key to `local.properties`:
   ```properties
   CURSEFORGE_API_KEY=your_key_here
   ```
   Never commit `local.properties` to version control.
4. Sync Gradle and build the APK via **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Runtime Setup (Minecraft Java on Android)
Running Minecraft Java Edition on Android requires cross-compiled OpenJDK (8/17/21), LWJGL-to-Android/GL4ES/Angle bridges, and JNI bindings:
1. Integrate an open-source Android Java runtime such as **Amethyst Android** / **PojavLauncher** native libraries (`arm64-v8a` and `x86_64`) into `app/src/main/jniLibs/`.
2. Connect `RuntimeManager.launchInstance(...)` to the native JNI launch entrypoint.

## Known Limitations
- **APK Compilation:** This source archive was generated in an environment without the Android SDK/NDK, so `AngelClient.apk` is not pre-built.
- **In-Game Modules & HUD:** Client-side in-game modules (Zoom, Free Look, HUD overlays, Capes/Wings) require a companion Fabric/Forge mod installed inside the launched Minecraft instance.
- **Social & Store:** Online friends, chat, voice chat, and real-money store purchases require a live backend server and Google Play Billing integration.

## Troubleshooting
- **CurseForge search says "API key not configured":** Ensure `CURSEFORGE_API_KEY` is set in `local.properties` and re-sync Gradle.
- **Modrinth download fails:** Verify the selected instance's Minecraft version matches an available release on Modrinth.
